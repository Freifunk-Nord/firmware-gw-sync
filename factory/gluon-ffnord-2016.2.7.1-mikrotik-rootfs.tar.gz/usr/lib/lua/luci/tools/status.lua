module("luci.tools.status",package.seeall)
local s=require"luci.model.uci".cursor()
local function r(o)
local e={}
local h=require"nixio.fs"
local t="/var/dhcp.leases"
s:foreach("dhcp","dnsmasq",
function(e)
if e.leasefile and h.access(e.leasefile)then
t=e.leasefile
return false
end
end)
local n=io.open(t,"r")
if n then
while true do
local t=n:read("*l")
if not t then
break
else
local i,s,a,t,n=t:match("^(%d+) (%S+) (%S+) (%S+) (%S+)")
if i and s and a and t and n then
if o==4 and not a:match(":")then
e[#e+1]={
expires=os.difftime(tonumber(i)or 0,os.time()),
macaddr=s,
ipaddr=a,
hostname=(t~="*")and t
}
elseif o==6 and a:match(":")then
e[#e+1]={
expires=os.difftime(tonumber(i)or 0,os.time()),
ip6addr=a,
duid=(n~="*")and n,
hostname=(t~="*")and t
}
end
end
end
end
n:close()
end
local t="/tmp/hosts/odhcpd"
s:foreach("dhcp","odhcpd",
function(e)
if e.leasefile and h.access(e.leasefile)then
t=e.leasefile
return false
end
end)
local i=io.open(t,"r")
if i then
while true do
local t=i:read("*l")
if not t then
break
else
local h,i,n,t,s,h,h,a=t:match("^# (%S+) (%S+) (%S+) (%S+) (%d+) (%S+) (%S+) (.*)")
if a and n~="ipv4"and o==6 then
e[#e+1]={
expires=os.difftime(tonumber(s)or 0,os.time()),
duid=i,
ip6addr=a,
hostname=(t~="-")and t
}
elseif a and n=="ipv4"and o==4 then
e[#e+1]={
expires=os.difftime(tonumber(s)or 0,os.time()),
macaddr=i,
ipaddr=a,
hostname=(t~="-")and t
}
end
end
end
i:close()
end
return e
end
function dhcp_leases()
return r(4)
end
function dhcp6_leases()
return r(6)
end
function wifi_networks()
local a={}
local e=require"luci.model.network".init()
local t
for e,t in ipairs(e:get_wifidevs())do
local o={
up=t:is_up(),
device=t:name(),
name=t:get_i18n(),
networks={}
}
local e
for i,e in ipairs(t:get_wifinets())do
o.networks[#o.networks+1]={
name=e:shortname(),
link=e:adminlink(),
up=e:is_up(),
mode=e:active_mode(),
ssid=e:active_ssid(),
bssid=e:active_bssid(),
encryption=e:active_encryption(),
frequency=e:frequency(),
channel=e:channel(),
signal=e:signal(),
quality=e:signal_percent(),
noise=e:noise(),
bitrate=e:bitrate(),
ifname=e:ifname(),
assoclist=e:assoclist(),
country=e:country(),
txpower=e:txpower(),
txpoweroff=e:txpower_offset(),
disabled=(t:get("disabled")=="1"or
e:get("disabled")=="1")
}
end
a[#a+1]=o
end
return a
end
function wifi_network(a)
local e=require"luci.model.network".init()
local e=e:get_wifinet(a)
if e then
local t=e:get_device()
if t then
return{
id=a,
name=e:shortname(),
link=e:adminlink(),
up=e:is_up(),
mode=e:active_mode(),
ssid=e:active_ssid(),
bssid=e:active_bssid(),
encryption=e:active_encryption(),
frequency=e:frequency(),
channel=e:channel(),
signal=e:signal(),
quality=e:signal_percent(),
noise=e:noise(),
bitrate=e:bitrate(),
ifname=e:ifname(),
assoclist=e:assoclist(),
country=e:country(),
txpower=e:txpower(),
txpoweroff=e:txpower_offset(),
disabled=(t:get("disabled")=="1"or
e:get("disabled")=="1"),
device={
up=t:is_up(),
device=t:name(),
name=t:get_i18n()
}
}
end
end
return{}
end
function switch_status(e)
local t
local o={}
for i in e:gmatch("[^%s,]+")do
local a={}
local t=io.popen("swconfig dev %q show"%i,"r")
if t then
local e
repeat
e=t:read("*l")
if e then
local t,n=e:match("port:(%d+) link:(%w+)")
if t then
local s=e:match(" speed:(%d+)")
local i=e:match(" (%w+)-duplex")
local o=e:match(" (txflow)")
local h=e:match(" (rxflow)")
local e=e:match(" (auto)")
a[#a+1]={
port=tonumber(t)or 0,
speed=tonumber(s)or 0,
link=(n=="up"),
duplex=(i=="full"),
rxflow=(not not h),
txflow=(not not o),
auto=(not not e)
}
end
end
until not e
t:close()
end
o[i]=a
end
return o
end
