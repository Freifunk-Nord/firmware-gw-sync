module("luci.http.protocol",package.seeall)
local h=require("luci.ltn12")
HTTP_MAX_CONTENT=1024*8
function urldecode(e,t)
local function a(e)
return string.char(tonumber(e,16))
end
if type(e)=="string"then
if not t then
e=e:gsub("+"," ")
end
e=e:gsub("%%([a-fA-F0-9][a-fA-F0-9])",a)
end
return e
end
function urldecode_params(e,t)
local t=t or{}
if e:find("?")then
e=e:gsub("^.+%?([^?]+)","%1")
end
for a in e:gmatch("[^&;]+")do
local e=urldecode(a:match("^([^=]+)"))
local a=urldecode(a:match("^[^=]+=(.+)$"))
if type(e)=="string"and e:len()>0 then
if type(a)~="string"then a=""end
if not t[e]then
t[e]=a
elseif type(t[e])~="table"then
t[e]={t[e],a}
else
table.insert(t[e],a)
end
end
end
return t
end
function urlencode(e)
local function t(e)
return string.format(
"%%%02x",string.byte(e)
)
end
if type(e)=="string"then
e=e:gsub(
"([^a-zA-Z0-9$_%-%.!*'(),])",
t
)
end
return e
end
function urlencode_params(t)
local e=""
for a,t in pairs(t)do
if type(t)=="table"then
for o,t in ipairs(t)do
e=e..(#e>0 and"&"or"")..
urlencode(a).."="..urlencode(t)
end
else
e=e..(#e>0 and"&"or"")..
urlencode(a).."="..urlencode(t)
end
end
return e
end
local function d(t,e)
if t[e]==nil then
t[e]=""
elseif type(t[e])=="string"then
t[e]={t[e],""}
else
table.insert(t[e],"")
end
end
local function l(t,e,a)
if type(t[e])=="table"then
t[e][#t[e]]=t[e][#t[e]]..a
else
t[e]=t[e]..a
end
end
local function c(t,e,a)
if a then
if type(t[e])=="table"then
t[e][#t[e]]=a(t[e][#t[e]])
else
t[e]=a(t[e])
end
end
end
local r={}
r['magic']=function(e,t,a)
if t~=nil then
if#t==0 then
return true,nil
end
local a,o,i=t:match("^([A-Z]+) ([^ ]+) HTTP/([01]%.[019])$")
if a then
e.type="request"
e.request_method=a:lower()
e.request_uri=o
e.http_version=tonumber(i)
e.headers={}
return true,function(t)
return r['headers'](e,t)
end
else
local a,t,o=t:match("^HTTP/([01]%.[019]) ([0-9]+) ([^\r\n]+)$")
if t then
e.type="response"
e.status_code=t
e.status_message=o
e.http_version=tonumber(a)
e.headers={}
return true,function(t)
return r['headers'](e,t)
end
end
end
end
return nil,"Invalid HTTP message magic"
end
r['headers']=function(o,a)
if a~=nil then
local t,e=a:match("^([A-Za-z][A-Za-z0-9%-_]+): +(.+)$")
if type(t)=="string"and t:len()>0 and
type(e)=="string"and e:len()>0
then
o.headers[t]=e
return true,nil
elseif#a==0 then
return false,nil
else
return nil,"Invalid HTTP header received"
end
else
return nil,"Unexpected EOF"
end
end
function header_source(e)
return h.source.simplify(function()
local e,t,a=e:receive("*l")
if e==nil then
if t~="timeout"then
return nil,a
and"Line exceeds maximum allowed length"
or"Unexpected EOF"
else
return nil,t
end
elseif e~=nil then
e=e:gsub("\r$","")
return e,nil
end
end)
end
function mimedecode_message_body(c,t,i)
if t and t.env.CONTENT_TYPE then
t.mime_boundary=t.env.CONTENT_TYPE:match("^multipart/form%-data; boundary=(.+)$")
end
if not t.mime_boundary then
return nil,"Invalid Content-Type found"
end
local s=0
local r=false
local o=nil
local n=nil
local a=nil
local function u(a,e)
local o
repeat
a,o=a:gsub(
"^([A-Z][A-Za-z0-9%-_]+): +([^\r\n]+)\r\n",
function(a,t)
e.headers[a]=t
return""
end
)
until o==0
a,o=a:gsub("^\r\n","")
if o>0 then
if e.headers["Content-Disposition"]then
if e.headers["Content-Disposition"]:match("^form%-data; ")then
e.name=e.headers["Content-Disposition"]:match('name="(.-)"')
e.file=e.headers["Content-Disposition"]:match('filename="(.+)"$')
end
end
if not e.headers["Content-Type"]then
e.headers["Content-Type"]="text/plain"
end
if e.name and e.file and i then
d(t.params,e.name)
l(t.params,e.name,e.file)
n=i
elseif e.name then
d(t.params,e.name)
n=function(o,a,o)
l(t.params,e.name,a)
end
else
n=nil
end
return a,true
end
return a,false
end
local function l(i)
s=s+(i and#i or 0)
if t.env.CONTENT_LENGTH and s>tonumber(t.env.CONTENT_LENGTH)+2 then
return nil,"Message body size exceeds Content-Length"
end
if i and not a then
a="\r\n"..i
elseif a then
local e=a..(i or"")
local s,d,h
repeat
s,d=e:find("\r\n--"..t.mime_boundary.."\r\n",1,true)
if not s then
s,d=e:find("\r\n--"..t.mime_boundary.."--\r\n",1,true)
end
if s then
local t=e:sub(1,s-1)
if r then
t,eof=u(t,o)
if not eof then
return nil,"Invalid MIME section header"
elseif not o.name then
return nil,"Invalid Content-Disposition header"
end
end
if n then
n(o,t,true)
end
o={headers={}}
h=h or true
e,eof=u(e:sub(d+1,#e),o)
r=not eof
end
until not s
if h then
a,e=e,nil
else
if r then
a,eof=u(e,o)
r=not eof
else
n(o,a,false)
a,i=i,nil
end
end
end
return true
end
return h.pump.all(c,l)
end
function urldecode_message_body(r,o)
local t=0
local a=nil
local function s(e)
t=t+(e and#e or 0)
if o.env.CONTENT_LENGTH and t>tonumber(o.env.CONTENT_LENGTH)+2 then
return nil,"Message body size exceeds Content-Length"
elseif t>HTTP_MAX_CONTENT then
return nil,"Message body size exceeds maximum allowed length"
end
if not a and e then
a=e
elseif a then
local e=a..(e or"&")
local i,n
repeat
i,n=e:find("^.-[;&]")
if i then
local a=e:sub(i,n-1)
local t=a:match("^(.-)=")
local a=a:match("=([^%s]*)%s*$")
if t and#t>0 then
d(o.params,t)
l(o.params,t,a)
c(o.params,t,urldecode)
end
e=e:sub(n+1,#e)
end
until not i
a=e
end
return true
end
return h.pump.all(r,s)
end
function parse_message_header(a)
local t=true
local e={}
local o=h.sink.simplify(
function(t)
return r['magic'](e,t)
end
)
while t do
t,err=h.pump.step(a,o)
if not t and err then
return nil,err
elseif not t then
if(e.request_method=="get"or e.request_method=="post")and
e.request_uri:match("?")
then
e.params=urldecode_params(e.request_uri)
else
e.params={}
end
e.env={
CONTENT_LENGTH=e.headers['Content-Length'];
CONTENT_TYPE=e.headers['Content-Type']or e.headers['Content-type'];
REQUEST_METHOD=e.request_method:upper();
REQUEST_URI=e.request_uri;
SCRIPT_NAME=e.request_uri:gsub("?.+$","");
SCRIPT_FILENAME="";
SERVER_PROTOCOL="HTTP/"..string.format("%.1f",e.http_version);
QUERY_STRING=e.request_uri:match("?")
and e.request_uri:gsub("^.+?","")or""
}
for a,t in ipairs({
'Accept',
'Accept-Charset',
'Accept-Encoding',
'Accept-Language',
'Connection',
'Cookie',
'Host',
'Referer',
'User-Agent',
})do
local a='HTTP_'..t:upper():gsub("%-","_")
local t=e.headers[t]
e.env[a]=t
end
end
end
return e
end
function parse_message_body(a,e,t)
if e.env.REQUEST_METHOD=="POST"and e.env.CONTENT_TYPE and
e.env.CONTENT_TYPE:match("^multipart/form%-data")
then
return mimedecode_message_body(a,e,t)
elseif e.env.REQUEST_METHOD=="POST"and e.env.CONTENT_TYPE and
e.env.CONTENT_TYPE:match("^application/x%-www%-form%-urlencoded")
then
return urldecode_message_body(a,e,t)
else
local o
if type(t)=="function"then
local e={
name="raw",
encoding=e.env.CONTENT_TYPE
}
o=function(a)
if a then
return t(e,a,false)
else
return t(e,nil,true)
end
end
else
e.content=""
e.content_length=0
o=function(t)
if t then
if(e.content_length+#t)<=HTTP_MAX_CONTENT then
e.content=e.content..t
e.content_length=e.content_length+#t
return true
else
return nil,"POST data exceeds maximum allowed length"
end
end
return true
end
end
while true do
local t,e=h.pump.step(a,o)
if not t and e then
return nil,e
elseif not t then
return true
end
end
return true
end
end
statusmsg={
[200]="OK",
[206]="Partial Content",
[301]="Moved Permanently",
[302]="Found",
[304]="Not Modified",
[400]="Bad Request",
[403]="Forbidden",
[404]="Not Found",
[405]="Method Not Allowed",
[408]="Request Time-out",
[411]="Length Required",
[412]="Precondition Failed",
[416]="Requested range not satisfiable",
[500]="Internal Server Error",
[503]="Server Unavailable",
}
