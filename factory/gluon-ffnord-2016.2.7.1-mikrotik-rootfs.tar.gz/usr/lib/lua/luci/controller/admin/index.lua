module("luci.controller.admin.index",package.seeall)
function index()
local e=luci.model.uci.cursor_state()
if e:get_first('gluon-setup-mode','setup_mode','running','0')~='1'then
return
end
local e=node()
if not e.lock then
e.target=alias("admin")
e.index=true
end
local e=entry({"admin"},alias("admin","index"),_("Advanced settings"),10)
e.sysauth="root"
e.sysauth_authenticator=function()return"root"end
e.index=true
entry({"admin","index"},cbi("admin/info"),_("Information"),1).ignoreindex=true
entry({"admin","remote"},cbi("admin/remote"),_("Remote access"),10)
end
