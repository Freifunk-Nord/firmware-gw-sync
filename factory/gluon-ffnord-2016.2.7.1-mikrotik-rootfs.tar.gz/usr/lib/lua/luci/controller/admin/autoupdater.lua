module("luci.controller.admin.autoupdater",package.seeall)
function index()
entry({"admin","autoupdater"},cbi("admin/autoupdater"),_("Automatic updates"),80)
end
