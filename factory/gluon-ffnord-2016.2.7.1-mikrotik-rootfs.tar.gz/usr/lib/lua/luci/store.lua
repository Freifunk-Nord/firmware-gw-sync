local e=require"luci.util"
module("luci.store",e.threadlocal)