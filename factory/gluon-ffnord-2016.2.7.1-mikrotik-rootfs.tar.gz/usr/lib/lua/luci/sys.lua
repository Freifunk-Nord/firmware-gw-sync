local n=require"io"
local l=require"os"
local w=require"table"
local a=require"nixio"
local i=require"nixio.fs"
local y=require"luci.model.uci"
local t={}
t.util=require"luci.util"
t.ip=require"luci.ip"
local o,m,c,p,s,e,v,b,u=
tonumber,ipairs,pairs,pcall,type,next,setmetatable,require,select
module"luci.sys"
function call(...)
return l.execute(...)/256
end
exec=t.util.exec
function mounts()
local n={}
local a={"fs","blocks","used","available","percent","mountpoint"}
local o=t.util.execi("df")
if not o then
return
else
o()
end
for i in o do
local t={}
local e=1
for o in i:gmatch("[^%s]+")do
t[a[e]]=o
e=e+1
end
if t[a[1]]then
if not t[a[2]]then
e=2
i=o()
for o in i:gmatch("[^%s]+")do
t[a[e]]=o
e=e+1
end
end
w.insert(n,t)
end
end
return n
end
getenv=a.getenv
function hostname(e)
if s(e)=="string"and#e>0 then
i.writefile("/proc/sys/kernel/hostname",e)
return e
else
return a.uname().nodename
end
end
function httpget(e,o,a)
if not a then
local t=o and n.popen or t.util.exec
return t("wget -qO- '"..e:gsub("'","").."'")
else
return l.execute("wget -qO '%s' '%s'"%
{a:gsub("'",""),e:gsub("'","")})
end
end
function reboot()
return l.execute("reboot >/dev/null 2>&1")
end
function syslog()
return t.util.exec("logread")
end
function dmesg()
return t.util.exec("dmesg")
end
function uniqueid(e)
local e=i.readfile("/dev/urandom",e)
return e and a.bin.hexlify(e)
end
function uptime()
return a.sysinfo().uptime
end
net={}
function net.arptable(a)
local t=(not a)and{}or nil
local o,o,e
if i.access("/proc/net/arp")then
for o in n.lines("/proc/net/arp")do
local e={},e
for t in o:gmatch("%S+")do
e[#e+1]=t
end
if e[1]~="IP"then
local e={
["IP address"]=e[1],
["HW type"]=e[2],
["Flags"]=e[3],
["HW address"]=e[4],
["Mask"]=e[5],
["Device"]=e[6]
}
if a then
a(e)
else
t=t or{}
t[#t+1]=e
end
end
end
end
return t
end
local function d(r,w)
local e,e,e,h,s,f
local y=y.cursor()
local d={}
local o={}
local function l(e,...)
local e=u(e,...)
if e then
if not o[e]then o[e]={}end
o[e][1]=u(1,...)or o[e][1]
o[e][2]=u(2,...)or o[e][2]
o[e][3]=u(3,...)or o[e][3]
o[e][4]=u(4,...)or o[e][4]
end
end
if i.access("/proc/net/arp")then
for e in n.lines("/proc/net/arp")do
s,h=e:match("^([%d%.]+)%s+%S+%s+%S+%s+([a-fA-F0-9:]+)%s+")
if s and h then
l(r,h:upper(),s,nil,nil)
end
end
end
if i.access("/etc/ethers")then
for e in n.lines("/etc/ethers")do
h,s=e:match("^([a-f0-9]%S+) (%S+)")
if h and s then
l(r,h:upper(),s,nil,nil)
end
end
end
if i.access("/var/dhcp.leases")then
for e in n.lines("/var/dhcp.leases")do
h,s,f=e:match("^%d+ (%S+) (%S+) (%S+)")
if h and s then
l(r,h:upper(),s,nil,f~="*"and f)
end
end
end
y:foreach("dhcp","host",
function(e)
for t in t.util.imatch(e.mac)do
l(r,t:upper(),e.ip,nil,e.name)
end
end)
for t,e in m(a.getifaddrs())do
if e.name~="lo"then
d[e.name]=d[e.name]or{}
if e.family=="packet"and e.addr and#e.addr==17 then
d[e.name][1]=e.addr:upper()
elseif e.family=="inet"then
d[e.name][2]=e.addr
elseif e.family=="inet6"then
d[e.name][3]=e.addr
end
end
end
for t,e in c(d)do
if e[r]and(e[2]or e[3])then
l(r,e[1],e[2],e[3],e[4])
end
end
for t,e in t.util.kspairs(o)do
w(e[1],e[2],e[3],e[4])
end
end
function net.mac_hints(n)
if n then
d(1,function(i,t,o,e)
e=e or a.getnameinfo(t or o,nil,100)or t
if e and e~=i then
n(i,e or a.getnameinfo(t or o,nil,100)or t)
end
end)
else
local o={}
d(1,function(i,t,n,e)
e=e or a.getnameinfo(t or n,nil,100)or t
if e and e~=i then
o[#o+1]={i,e or a.getnameinfo(t or n,nil,100)or t}
end
end)
return o
end
end
function net.ipv4_hints(o)
if o then
d(2,function(i,t,n,e)
e=e or a.getnameinfo(t,nil,100)or i
if e and e~=t then
o(t,e)
end
end)
else
local o={}
d(2,function(i,t,n,e)
e=e or a.getnameinfo(t,nil,100)or i
if e and e~=t then
o[#o+1]={t,e}
end
end)
return o
end
end
function net.ipv6_hints(o)
if o then
d(3,function(i,n,t,e)
e=e or a.getnameinfo(t,nil,100)or i
if e and e~=t then
o(t,e)
end
end)
else
local t={}
d(3,function(i,n,o,e)
e=e or a.getnameinfo(o,nil,100)or i
if e and e~=o then
t[#t+1]={o,e}
end
end)
return t
end
end
function net.conntrack(a)
local t={}
if i.access("/proc/net/nf_conntrack","r")then
for e in n.lines("/proc/net/nf_conntrack")do
e=e:match"^(.-( [^ =]+=).-)%2"
local e,o=_parse_mixed_record(e," +")
if o[6]~="TIME_WAIT"then
e.layer3=o[1]
e.layer4=o[3]
for t=1,#e do
e[t]=nil
end
if a then
a(e)
else
t[#t+1]=e
end
end
end
elseif i.access("/proc/net/ip_conntrack","r")then
for e in n.lines("/proc/net/ip_conntrack")do
e=e:match"^(.-( [^ =]+=).-)%2"
local e,o=_parse_mixed_record(e," +")
if o[4]~="TIME_WAIT"then
e.layer3="ipv4"
e.layer4=o[1]
for t=1,#e do
e[t]=nil
end
if a then
a(e)
else
t[#t+1]=e
end
end
end
else
return nil
end
return t
end
function net.devices()
local e={}
for a,t in m(a.getifaddrs())do
if t.family=="packet"then
e[#e+1]=t.name
end
end
return e
end
function net.deviceinfo()
local o={}
for e,t in m(a.getifaddrs())do
if t.family=="packet"then
local e=t.data
e[1]=e.rx_bytes
e[2]=e.rx_packets
e[3]=e.rx_errors
e[4]=e.rx_dropped
e[5]=0
e[6]=0
e[7]=0
e[8]=e.multicast
e[9]=e.tx_bytes
e[10]=e.tx_packets
e[11]=e.tx_errors
e[12]=e.tx_dropped
e[13]=0
e[14]=e.collisions
e[15]=0
e[16]=0
o[t.name]=e
end
end
return o
end
function net.routes(s)
local i={}
for e in n.lines("/proc/net/route")do
local h,n,a,d,r,l,c,
e,u,f,m=e:match(
"([^%s]+)\t([A-F0-9]+)\t([A-F0-9]+)\t([A-F0-9]+)\t"..
"(%d+)\t(%d+)\t(%d+)\t([A-F0-9]+)\t(%d+)\t(%d+)\t(%d+)"
)
if h then
a=t.ip.Hex(a,32,t.ip.FAMILY_INET4)
e=t.ip.Hex(e,32,t.ip.FAMILY_INET4)
n=t.ip.Hex(
n,e:prefix(e),t.ip.FAMILY_INET4
)
local e={
dest=n,
gateway=a,
metric=o(c),
refcount=o(r),
usecount=o(l),
mtu=o(u),
window=o(window),
irtt=o(m),
flags=o(d,16),
device=h
}
if s then
s(e)
else
i[#i+1]=e
end
end
end
return i
end
function net.routes6(r)
if i.access("/proc/net/ipv6_route","r")then
local s={}
for e in n.lines("/proc/net/ipv6_route")do
local e,d,i,h,a,
n,u,l,c,m=e:match(
"([a-f0-9]+) ([a-f0-9]+) "..
"([a-f0-9]+) ([a-f0-9]+) "..
"([a-f0-9]+) ([a-f0-9]+) "..
"([a-f0-9]+) ([a-f0-9]+) "..
"([a-f0-9]+) +([^%s]+)"
)
if e and d and
i and h and
a and n and
u and l and
c and m
then
i=t.ip.Hex(
i,o(h,16),t.ip.FAMILY_INET6,false
)
e=t.ip.Hex(
e,o(d,16),t.ip.FAMILY_INET6,false
)
a=t.ip.Hex(a,128,t.ip.FAMILY_INET6,false)
local e={
source=i,
dest=e,
nexthop=a,
metric=o(n,16),
refcount=o(u,16),
usecount=o(l,16),
flags=o(c,16),
device=m,
metric_raw=n
}
if r then
r(e)
else
s[#s+1]=e
end
end
end
return s
end
end
function net.pingtest(e)
return l.execute("ping -c1 '"..e:gsub("'",'').."' >/dev/null 2>&1")
end
process={}
function process.info(e)
local t={uid=a.getuid(),gid=a.getgid()}
return not e and t or t[e]
end
function process.list()
local a={}
local e
local e=t.util.execi("/bin/busybox top -bn1")
if not e then
return
end
for e in e do
local t,i,n,h,s,d,r,l=e:match(
"^ *(%d+) +(%d+) +(%S.-%S) +([RSDZTW][W ][<N ]) +(%d+) +(%d+%%) +(%d+%%) +(.+)"
)
local e=o(t)
if e then
a[e]={
['PID']=t,
['PPID']=i,
['USER']=n,
['STAT']=h,
['VSZ']=s,
['%MEM']=d,
['%CPU']=r,
['COMMAND']=l
}
end
end
return a
end
function process.setgroup(e)
return a.setgid(e)
end
function process.setuser(e)
return a.setuid(e)
end
process.signal=a.kill
user={}
user.getuser=a.getpw
function user.getpasswd(e)
local t=a.getsp and a.getsp(e)or a.getpw(e)
local e=t and(t.pwdp or t.passwd)
if not e or#e<1 or e=="!"or e=="x"then
return nil,t
else
return e,t
end
end
function user.checkpasswd(e,o)
local e,t=user.getpasswd(e)
if t then
return(e==nil or a.crypt(o,e)==e)
end
return false
end
function user.setpasswd(t,e)
if e then
e=e:gsub("'",[['"'"']])
end
if t then
t=t:gsub("'",[['"'"']])
end
return l.execute(
"(echo '"..e.."'; sleep 1; echo '"..e.."') | "..
"passwd '"..t.."' >/dev/null 2>&1"
)
end
wifi={}
function wifi.getiwinfo(e)
local h,s=p(b,"iwinfo")
if e then
local i=0
local a=y.cursor_state()
local n,t=e:match("^(%w+)%.network(%d+)")
if n and t then
e=n
t=o(t)
a:foreach("wireless","wifi-iface",
function(a)
if a.device==n then
i=i+1
if i==t then
e=a.ifname or a.device
return false
end
end
end)
elseif a:get("wireless",e)=="wifi-device"then
a:foreach("wireless","wifi-iface",
function(t)
if t.device==e and t.ifname then
e=t.ifname
return false
end
end)
end
local t=h and s.type(e)
local a=t and s[t]or{}
return v({},{
__index=function(o,t)
if t=="ifname"then
return e
elseif a[t]then
return a[t](e)
end
end
})
end
end
init={}
init.dir="/etc/init.d/"
function init.names()
local e={}
for t in i.glob(init.dir.."*")do
e[#e+1]=i.basename(t)
end
return e
end
function init.index(e)
if i.access(init.dir..e)then
return call("env -i sh -c 'source %s%s enabled; exit ${START:-255}' >/dev/null"
%{init.dir,e})
end
end
local function e(t,e)
if i.access(init.dir..e)then
return call("env -i %s%s %s >/dev/null"%{init.dir,e,t})
end
end
function init.enabled(t)
return(e("enabled",t)==0)
end
function init.enable(t)
return(e("enable",t)==1)
end
function init.disable(t)
return(e("disable",t)==0)
end
function init.start(t)
return(e("start",t)==0)
end
function init.stop(t)
return(e("stop",t)==0)
end
function _parse_mixed_record(i,e)
e=e or"  "
local o={}
local a={}
for n,i in c(t.util.split(t.util.trim(i),"\n"))do
for t,e in c(t.util.split(t.util.trim(i),e,nil,true))do
local e,t,i=e:match('([^%s][^:=]*) *([:=]*) *"*([^\n"]*)"*')
if e then
if t==""then
w.insert(a,e)
else
o[e]=i
end
end
end
end
return o,a
end
