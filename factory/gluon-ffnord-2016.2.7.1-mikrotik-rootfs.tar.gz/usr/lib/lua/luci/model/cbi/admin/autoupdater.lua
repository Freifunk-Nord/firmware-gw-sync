m=Map("autoupdater",translate("Automatic updates"))
m.pageaction=false
m.template="admin/expertmode"
s=m:section(TypedSection,"autoupdater",nil)
s.addremove=false
s.anonymous=true
s:option(Flag,"enabled",translate("Enable"))
f=s:option(ListValue,"branch",translate("Branch"))
uci.cursor():foreach("autoupdater","branch",function(e)f:value(e[".name"])end)
return m
