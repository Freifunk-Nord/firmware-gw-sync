local e=luci.model.uci.cursor()
local t=require'nixio.fs'
local a=require'iwinfo'
local function h(e)
for e in t.glob("/sys/devices/"..e.."/ieee80211/phy*")do
return e:match("([^/]+)$")
end
end
local function r(e)
local a=e:lower()
for e in t.glob("/sys/class/ieee80211/*/macaddress")do
if luci.util.trim(t.readfile(e))==a then
return e:match("([^/]+)/macaddress$")
end
end
end
local function d(e)
local t=a.nl80211.txpwrlist(e)or{}
local e=tonumber(a.nl80211.txpower_offset(e))or 0
local a={}
local i=-1
local o,o
for t,o in ipairs(t)do
local t=o.dbm+e
local e=math.floor(10^(t/10))
if e~=i then
i=e
table.insert(a,{
display_dbm=t,
display_mw=e,
driver_dbm=o.dbm,
})
end
end
return a
end
local n=SimpleForm("wifi",translate("WLAN"))
n.template="admin/expertmode"
local t=n:section(SimpleSection,nil,translate(
"You can enable or disable your node's client and mesh network "
.."SSIDs here. Please don't disable the mesh network without "
.."a good reason, so other nodes can mesh with yours.<br /><br />"
.."It is also possible to configure the WLAN adapters transmission power "
.."here. Please note that the transmission power values include the antenna gain "
.."where available, but there are many devices for which the gain is unavailable or inaccurate."
))
local s={}
e:foreach('wireless','wifi-device',
function(e)
table.insert(s,e['.name'])
end
)
for t,a in ipairs(s)do
local o=e:get_all('wireless',a)
local i
if o.hwmode=='11g'or o.hwmode=='11ng'then
i=n:section(SimpleSection,translate("2.4GHz WLAN"))
elseif o.hwmode=='11a'or o.hwmode=='11na'then
i=n:section(SimpleSection,translate("5GHz WLAN"))
end
if i then
local t
if e:get('wireless','client_'..a)then
t=i:option(Flag,a..'_client_enabled',translate("Enable client network (access point)"))
t.default=e:get_bool('wireless','client_'..a,"disabled")and t.disabled or t.enabled
t.rmempty=false
end
if e:get('wireless','mesh_'..a)then
t=i:option(Flag,a..'_mesh_enabled',translate("Enable mesh network (802.11s)"))
t.default=e:get_bool('wireless','mesh_'..a,"disabled")and t.disabled or t.enabled
t.rmempty=false
end
if e:get('wireless','ibss_'..a)then
t=i:option(Flag,a..'_ibss_enabled',translate("Enable mesh network (IBSS)"))
t.default=e:get_bool('wireless','ibss_'..a,"disabled")and t.disabled or t.enabled
t.rmempty=false
end
local t
if o.path then
t=h(o.path)
elseif o.macaddr then
t=r(o.macaddr)
end
if t then
local o=d(t)
if#o>1 then
local t=i:option(ListValue,a..'_txpower',translate("Transmission power"))
t.rmempty=true
t.default=e:get('wireless',a,'txpower')or'default'
t:value('default',translate("(default)"))
table.sort(o,function(t,e)return t.driver_dbm>e.driver_dbm end)
for a,e in ipairs(o)do
t:value(e.driver_dbm,"%i dBm (%i mW)"%{e.display_dbm,e.display_mw})
end
end
end
end
end
function n.handle(o,t,a)
if t==FORM_VALID then
for o,t in ipairs(s)do
if e:get('wireless','client_'..t)then
local o=0
if a[t..'_client_enabled']=='0'then
o=1
end
e:set('wireless','client_'..t,"disabled",o)
end
if e:get('wireless','mesh_'..t)then
local o=0
if a[t..'_mesh_enabled']=='0'then
o=1
end
e:set('wireless','mesh_'..t,"disabled",o)
end
if e:get('wireless','ibss_'..t)then
local o=0
if a[t..'_ibss_enabled']=='0'then
o=1
end
e:set('wireless','ibss_'..t,"disabled",o)
end
if a[t..'_txpower']then
if a[t..'_txpower']=='default'then
e:delete('wireless',t,'txpower')
else
e:set('wireless',t,'txpower',a[t..'_txpower'])
end
end
end
e:save('wireless')
e:commit('wireless')
end
end
return n
