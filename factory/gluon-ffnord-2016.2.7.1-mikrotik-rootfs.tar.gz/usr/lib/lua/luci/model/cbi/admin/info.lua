local e=Template('admin/info')
e.pageaction=false
return e
