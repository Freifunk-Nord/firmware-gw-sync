local a,e,t=...
local u=t:get_interface()
local d,t,l,r,n,i,i,a,o
local i,h
d=e:taboption("general",Value,"ipaddr",translate("IPv4 address"))
d.datatype="ip4addr"
t=e:taboption("general",Value,"netmask",
translate("IPv4 netmask"))
t.datatype="ip4addr"
t:value("255.255.255.0")
t:value("255.255.0.0")
t:value("255.0.0.0")
l=e:taboption("general",Value,"gateway",translate("IPv4 gateway"))
l.datatype="ip4addr"
r=e:taboption("general",Value,"broadcast",translate("IPv4 broadcast"))
r.datatype="ip4addr"
n=e:taboption("general",DynamicList,"dns",
translate("Use custom DNS servers"))
n.datatype="ipaddr"
n.cast="string"
if luci.model.network:has_ipv6()then
local t=e:taboption("general",Value,"ip6assign",translate("IPv6 assignment length"),
translate("Assign a part of given length of every public IPv6-prefix to this interface"))
t:value("",translate("disabled"))
t:value("64")
t.datatype="max(64)"
local t=e:taboption("general",Value,"ip6hint",translate("IPv6 assignment hint"),
translate("Assign prefix parts using this hexadecimal subprefix ID for this interface."))
for e=33,64 do t:depends("ip6assign",e)end
a=e:taboption("general",Value,"ip6addr",translate("IPv6 address"))
a.datatype="ip6addr"
a:depends("ip6assign","")
o=e:taboption("general",Value,"ip6gw",translate("IPv6 gateway"))
o.datatype="ip6addr"
o:depends("ip6assign","")
local e=s:taboption("general",Value,"ip6prefix",translate("IPv6 routed prefix"),
translate("Public prefix routed to this device for distribution to clients."))
e.datatype="ip6addr"
e:depends("ip6assign","")
end
luci.tools.proto.opt_macaddr(e,u,translate("Override MAC address"))
i=e:taboption("advanced",Value,"mtu",translate("Override MTU"))
i.placeholder="1500"
i.datatype="max(9200)"
h=e:taboption("advanced",Value,"metric",
translate("Use gateway metric"))
h.placeholder="0"
h.datatype="uinteger"
