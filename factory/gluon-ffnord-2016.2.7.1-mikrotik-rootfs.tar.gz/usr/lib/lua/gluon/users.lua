local e=require'gluon.util'
local t=os
local a=string
module'gluon.users'
function add_user(t,i,o)
e.lock('/var/lock/passwd')
e.replace_prefix('/etc/passwd',t..':',a.format('%s:*:%u:%u::/var:/bin/false\n',t,i,o))
e.replace_prefix('/etc/shadow',t..':',a.format('%s:*:0:0:99999:7:::\n',t))
e.unlock('/var/lock/passwd')
end
function remove_user(t)
e.lock('/var/lock/passwd')
e.replace_prefix('/etc/passwd',t..':')
e.replace_prefix('/etc/shadow',t..':')
e.unlock('/var/lock/passwd')
end
function add_group(t,o)
e.lock('/var/lock/group')
e.replace_prefix('/etc/group',t..':',a.format('%s:x:%u:\n',t,o))
e.unlock('/var/lock/group')
end
function remove_group(t)
e.lock('/var/lock/group')
e.replace_prefix('/etc/group',t..':')
e.unlock('/var/lock/group')
end
