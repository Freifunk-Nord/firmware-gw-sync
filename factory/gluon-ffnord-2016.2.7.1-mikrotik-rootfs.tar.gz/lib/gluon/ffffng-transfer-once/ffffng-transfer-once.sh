#!/bin/sh
PATH=/usr/sbin:/usr/bin:/sbin:/bin

UPD='http://[fd42:eb49:c0b5:4242::fd00]/ffffng-transfer'


MAC="$(uci get network.client.macaddr | tr \[a-z] [A-Z])"
wget -q $UPD/$MAC -O-|head -c200 |head -n1> /tmp/a
source /tmp/a

if [ "$H" ]; then
  uci set system.@system[0].hostname="$H"
  uci commit system
fi
if [ "$LAT" ]; then
  uci set gluon-node-info.@location[0].latitude="$LAT"
  uci set gluon-node-info.@location[0].longitude="$LON"
  uci set gluon-node-info.@location[0].share_location="1"
fi
if [ "$O" ]; then
  uci set gluon-node-info.@owner[0].contact="$O"
  uci commit gluon-node-info
  rm /usr/lib/micron.d/ffffng-transfer-once
  rm -Rf /lib/gluon/ffffng-transfer-once
  /etc/init.d/micrond restart
  logger -s -t "ffffng-transfer-once" -p 5 "update"
fi
